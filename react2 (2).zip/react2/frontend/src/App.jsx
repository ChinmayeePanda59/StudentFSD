import Student from "./Student";
import "./App.css";

function App() {
  return (
    <div className="app">
      <header>
        <h1>Student Profile</h1>
        <p>Welcome to our Student Portal</p>
      </header>

      <div className="student-container">

        <Student
          name="Chinmayee Panda"
          course="B.Tech Computer Science"
          college=" GIET University"
        />

        <Student
          name="Priya Kumari"
          course="B.Sc"
          college="SOA"
        />

      </div>
    </div>
  );
}

export default App;