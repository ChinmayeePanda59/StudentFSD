function Student(props) {
  return (
    <div className="student-card">
      <div className="profile-icon">
        👨‍🎓
      </div>

      <h2>{props.name}</h2>

      <div className="info">
        <p>
          <span>📚 Course</span>
          {props.course}
        </p>

        <p>
          <span>🏫 College</span>
          {props.college}
        </p>
      </div>
    </div>
  );
}

export default Student;