import { useParams } from "react-router-dom";

function CourseDetails() {

  const { id } = useParams();

  const courses = {
    1: {
      name: "React Development",
      duration: "8 Weeks",
      level: "Intermediate"
    },

    2: {
      name: "Java Programming",
      duration: "10 Weeks",
      level: "Beginner"
    }
  };

  const course = courses[id];

  return (
    <div className="page">

      {course ? (

        <div className="details-card">

          <h1>{course.name}</h1>

          <p>
            <strong>Course ID:</strong> {id}
          </p>

          <p>
            <strong>Duration:</strong> {course.duration}
          </p>

          <p>
            <strong>Level:</strong> {course.level}
          </p>

        </div>

      ) : (

        <h1>Course Not Found ❌</h1>

      )}

    </div>
  );
}

export default CourseDetails;