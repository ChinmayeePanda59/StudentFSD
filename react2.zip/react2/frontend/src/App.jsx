import { useMemo, useState } from 'react'
import './App.css'

const movies = [
  {
    id: 'pathaan',
    title: 'Pathaan',
    genre: 'Action Thriller',
    rating: '8.1',
    duration: '2h 15m',
    synopsis: 'A daring spy thriller where one agent must go rogue to stop an international threat.',
    banner: 'linear-gradient(135deg, #0f172a 0%, #0f2957 100%)',
    showtimes: ['10:30 AM', '01:45 PM', '05:00 PM', '08:30 PM'],
    totalSeats: 48,
    bookedSeats: ['A1', 'A2', 'B4', 'B5', 'C3', 'D6', 'F7'],
  },
  {
    id: 'love-legacy',
    title: 'Love Legacy',
    genre: 'Romantic Drama',
    rating: '7.7',
    duration: '2h 5m',
    synopsis: 'A heartfelt romance about two strangers whose chance meeting transforms their lives forever.',
    banner: 'linear-gradient(135deg, #4c1d95 0%, #db2777 100%)',
    showtimes: ['11:00 AM', '02:15 PM', '06:00 PM', '09:15 PM'],
    totalSeats: 42,
    bookedSeats: ['A3', 'A5', 'B1', 'C7', 'D2', 'E4'],
  },
  {
    id: 'thrill-nights',
    title: 'Thrill Nights',
    genre: 'Mystery Horror',
    rating: '8.4',
    duration: '2h 20m',
    synopsis: 'A gripping mystery where every solved clue opens the door to a darker secret.',
    banner: 'linear-gradient(135deg, #111827 0%, #7c3aed 100%)',
    showtimes: ['12:00 PM', '03:30 PM', '07:00 PM', '10:00 PM'],
    totalSeats: 50,
    bookedSeats: ['B2', 'B3', 'C4', 'D1', 'E8', 'F2'],
  },
]

const seatRows = ['A', 'B', 'C', 'D', 'E', 'F']
const seatCols = [1, 2, 3, 4, 5, 6, 7, 8]
const seatPrice = 320

function App() {
  const [isSignup, setIsSignup] = useState(false)
  const [authState, setAuthState] = useState({ name: '', email: '', password: '' })
  const [user, setUser] = useState(null)
  const [page, setPage] = useState('auth')
  const [selectedMovieId, setSelectedMovieId] = useState(null)
  const [selectedShowtime, setSelectedShowtime] = useState('')
  const [selectedSeats, setSelectedSeats] = useState([])
  const [bookingTicket, setBookingTicket] = useState(null)
  const [statusMessage, setStatusMessage] = useState('')
  const [movieBookings, setMovieBookings] = useState(() => {
    const initial = {}
    movies.forEach((movie) => {
      initial[movie.id] = new Set(movie.bookedSeats)
    })
    return initial
  })

  const selectedMovie = useMemo(
    () => movies.find((movie) => movie.id === selectedMovieId),
    [selectedMovieId],
  )

  const canProceedToSeats = selectedMovie && selectedShowtime
  const totalAmount = selectedSeats.length * seatPrice

  const handleAuthSubmit = (event) => {
    event.preventDefault()
    const trimmedName = authState.name.trim()
    const trimmedEmail = authState.email.trim()
    const trimmedPassword = authState.password.trim()

    if (!trimmedEmail || !trimmedPassword || (isSignup && !trimmedName)) {
      setStatusMessage('Please complete all fields before continuing.')
      return
    }

    setUser({ name: trimmedName || 'Guest', email: trimmedEmail })
    setPage('movies')
    setStatusMessage('')
  }

  const toggleSeat = (seat) => {
    if (!selectedMovie) return
    const isBooked = movieBookings[selectedMovie.id].has(seat)
    if (isBooked) return

    setSelectedSeats((current) => {
      if (current.includes(seat)) {
        return current.filter((item) => item !== seat)
      }
      return [...current, seat].sort()
    })
  }

  const handleBooking = () => {
    if (!selectedSeats.length) {
      setStatusMessage('Select at least one seat to continue.')
      return
    }
    if (!selectedMovie) return

    setMovieBookings((existing) => {
      const updated = { ...existing }
      const booked = new Set(updated[selectedMovie.id])
      selectedSeats.forEach((seat) => booked.add(seat))
      updated[selectedMovie.id] = booked
      return updated
    })

    const ticket = {
      id: `BK-${Date.now()}`,
      movie: selectedMovie,
      showtime: selectedShowtime,
      seats: [...selectedSeats],
      amount: totalAmount,
      bookedAt: new Date().toLocaleString(),
    }
    setBookingTicket(ticket)
    setPage('confirmation')
    setStatusMessage('')
  }

  const resetBooking = () => {
    setSelectedMovieId(null)
    setSelectedShowtime('')
    setSelectedSeats([])
    setBookingTicket(null)
    setPage('movies')
    setStatusMessage('')
  }

  const downloadTicket = () => {
    if (!bookingTicket) return

    const lines = [
      'MOVIE TICKET',
      '============',
      `Ticket ID: ${bookingTicket.id}`,
      `Movie: ${bookingTicket.movie.title}`,
      `Genre: ${bookingTicket.movie.genre}`,
      `Showtime: ${bookingTicket.showtime}`,
      `Seats: ${bookingTicket.seats.join(', ')}`,
      `Price: ₹${bookingTicket.amount}`,
      `Booked By: ${user?.name || 'Guest'}`,
      `Email: ${user?.email || 'N/A'}`,
      `Booked At: ${bookingTicket.bookedAt}`,
      '',
      'Enjoy your movie night!',
    ]

    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = `${bookingTicket.movie.title.replace(/\s+/g, '_')}_ticket.txt`
    document.body.appendChild(anchor)
    anchor.click()
    anchor.remove()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="app-shell">
      <header className="hero-banner">
        <div className="hero-copy">
          <span className="eyebrow">Bollywood premiere booking</span>
          <h1>Feel the thrill of premium movie booking</h1>
          <p>
            Login or sign up and reserve the best seats for the latest Bollywood
            releases with a premium, all-in-one experience.
          </p>
        </div>
        <div className="hero-pill">
          <span>Fastest booking</span>
          <span>Elegant UI</span>
          <span>Instant ticket</span>
        </div>
      </header>

      {!user && page === 'auth' && (
        <section className="auth-panel glass-card">
          <div className="auth-headline">
            <h2>{isSignup ? 'Create your account' : 'Welcome back'}</h2>
            <p>
              {isSignup
                ? 'Sign up to book premium seats for the biggest releases.'
                : 'Login to choose your movie, seats, and confirm instantly.'}
            </p>
          </div>

          <div className="auth-toggle">
            <button
              type="button"
              className={!isSignup ? 'toggle-button active' : 'toggle-button'}
              onClick={() => {
                setIsSignup(false)
                setStatusMessage('')
              }}
            >
              Login
            </button>
            <button
              type="button"
              className={isSignup ? 'toggle-button active' : 'toggle-button'}
              onClick={() => {
                setIsSignup(true)
                setStatusMessage('')
              }}
            >
              Signup
            </button>
          </div>

          <form className="auth-form" onSubmit={handleAuthSubmit}>
            {isSignup && (
              <label>
                Name
                <input
                  value={authState.name}
                  onChange={(event) =>
                    setAuthState((prev) => ({ ...prev, name: event.target.value }))
                  }
                  placeholder="Your name"
                  required={isSignup}
                />
              </label>
            )}
            <label>
              Email
              <input
                type="email"
                value={authState.email}
                onChange={(event) =>
                  setAuthState((prev) => ({ ...prev, email: event.target.value }))
                }
                placeholder="hello@moviepass.com"
                required
              />
            </label>
            <label>
              Password
              <input
                type="password"
                value={authState.password}
                onChange={(event) =>
                  setAuthState((prev) => ({ ...prev, password: event.target.value }))
                }
                placeholder="Enter a secure password"
                required
              />
            </label>
            <button type="submit" className="primary-button">
              {isSignup ? 'Create account' : 'Login securely'}
            </button>
          </form>
          {statusMessage && <p className="status-text">{statusMessage}</p>}
        </section>
      )}

      {user && page === 'movies' && (
        <main className="content-area">
          <section className="movie-intro">
            <div>
              <p className="user-greeting">Hello, {user.name}</p>
              <h2>Choose your blockbuster</h2>
              <p>
                Select a recent Bollywood hit, pick showtimes, and reserve premium
                seats in one tap.
              </p>
            </div>
            <button className="secondary-button" onClick={() => setPage('auth')}>
              Logout
            </button>
          </section>

          <section className="movie-grid">
            {movies.map((movie) => (
              <article key={movie.id} className="movie-card">
                <div
                  className="movie-banner"
                  style={{ background: movie.banner }}
                >
                  <div className="movie-tag">{movie.genre}</div>
                  <div className="movie-badge">{movie.rating} ⭐</div>
                </div>
                <div className="movie-body">
                  <h3>{movie.title}</h3>
                  <p className="movie-meta">{movie.duration}</p>
                  <p className="movie-desc">{movie.synopsis}</p>
                  <div className="showtime-list">
                    {movie.showtimes.map((time) => (
                      <button
                        key={time}
                        type="button"
                        className="time-chip"
                        onClick={() => {
                          setSelectedMovieId(movie.id)
                          setSelectedShowtime(time)
                          setSelectedSeats([])
                          setPage('seats')
                        }}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </section>
        </main>
      )}

      {user && page === 'seats' && selectedMovie && (
        <main className="content-area booking-view">
          <section className="booking-summary glass-card">
            <div className="booking-heading">
              <h2>{selectedMovie.title}</h2>
              <p>{selectedMovie.genre}</p>
            </div>
            <div className="booking-detail">
              <p>
                Showtime <strong>{selectedShowtime}</strong>
              </p>
              <p>
                Available seats{' '}
                <strong>
                  {selectedMovie.totalSeats - movieBookings[selectedMovie.id].size}
                </strong>
              </p>
              <p>Price per seat ₹{seatPrice}</p>
            </div>
            <div className="seat-legend">
              <div>
                <span className="legend-box available" /> Available
              </div>
              <div>
                <span className="legend-box selected" /> Selected
              </div>
              <div>
                <span className="legend-box booked" /> Booked
              </div>
            </div>

            <div className="seat-grid">
              {seatRows.map((row) => (
                <div key={row} className="seat-row">
                  <span className="row-label">{row}</span>
                  {seatCols.map((col) => {
                    const seatId = `${row}${col}`
                    const isBooked = movieBookings[selectedMovie.id].has(seatId)
                    const isSelected = selectedSeats.includes(seatId)
                    return (
                      <button
                        key={seatId}
                        type="button"
                        className={`seat ${isBooked ? 'seat-booked' : isSelected ? 'seat-selected' : 'seat-open'}`}
                        disabled={isBooked}
                        onClick={() => toggleSeat(seatId)}
                      >
                        {col}
                      </button>
                    )
                  })}
                </div>
              ))}
            </div>

            <div className="booking-actions">
              <div>
                <p>Selected seats</p>
                <strong>{selectedSeats.length ? selectedSeats.join(', ') : 'None'}</strong>
              </div>
              <div>
                <p>Subtotal</p>
                <strong>₹{totalAmount}</strong>
              </div>
            </div>
            <div className="action-row">
              <button type="button" className="secondary-button" onClick={() => setPage('movies')}>
                Back to movies
              </button>
              <button type="button" className="primary-button" onClick={handleBooking}>
                Confirm booking
              </button>
            </div>
            {statusMessage && <p className="status-text">{statusMessage}</p>}
          </section>

          <aside className="booking-promo glass-card">
            <h3>Premium cinema club</h3>
            <p>
              Choose the best views, enjoy express entry, and receive a digital
              ticket instantly upon booking.
            </p>
            <ul>
              <li>Luxury seat selection</li>
              <li>Instant confirmation email</li>
              <li>Download ticket securely</li>
            </ul>
            <div className="promo-banner">
              <span>NEW</span>
              <p>Book your seat for the most anticipated Hindi releases now.</p>
            </div>
          </aside>
        </main>
      )}

      {user && page === 'confirmation' && bookingTicket && (
        <main className="content-area confirmation-view">
          <section className="ticket-card glass-card">
            <div className="ticket-header">
              <div>
                <span className="ticket-tag">Confirmed</span>
                <h2>{bookingTicket.movie.title}</h2>
                <p>{bookingTicket.movie.synopsis}</p>
              </div>
              <div className="ticket-meta">
                <strong>Ticket ID</strong>
                <span>{bookingTicket.id}</span>
              </div>
            </div>

            <div className="ticket-details-grid">
              <div>
                <h4>Showtime</h4>
                <p>{bookingTicket.showtime}</p>
              </div>
              <div>
                <h4>Seats</h4>
                <p>{bookingTicket.seats.join(', ')}</p>
              </div>
              <div>
                <h4>Amount</h4>
                <p>₹{bookingTicket.amount}</p>
              </div>
              <div>
                <h4>Booked by</h4>
                <p>{user.name}</p>
              </div>
            </div>

            <div className="ticket-footer">
              <p>
                Present this digital ticket at the theater entry. Download it for
                easy access anytime.
              </p>
              <div className="action-row">
                <button type="button" className="secondary-button" onClick={resetBooking}>
                  Book another show
                </button>
                <button type="button" className="primary-button" onClick={downloadTicket}>
                  Download ticket
                </button>
              </div>
            </div>
          </section>
        </main>
      )}
    </div>
  )
}

export default App
