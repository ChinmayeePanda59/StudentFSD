import { Link } from "react-router-dom";

function Courses() {

  const courses = [
    {
      id: 1,
      title: "React Development",
      category: "Web Development",
      description:
        "Learn React components, JSX, props, state, hooks and routing.",
      duration: "8 Weeks",
      level: "Intermediate"
    },
    {
      id: 2,
      title: "Java Programming",
      category: "Programming",
      description:
        "Learn Java fundamentals, OOP concepts, collections and problem solving.",
      duration: "10 Weeks",
      level: "Beginner"
    }
  ];

  return (
    <div className="page courses-page">

      <div className="page-header">
        <span className="page-tag">LEARNING PROGRAMS</span>

        <h1>Explore Our Courses</h1>

        <p>
          Build your skills with carefully designed courses
          for students and developers.
        </p>
      </div>

      <div className="course-container">

        {courses.map((course) => (

          <div className="course-card" key={course.id}>

            <div className="course-icon">
              {course.id === 1 ? "⚛️" : "☕"}
            </div>

            <span className="course-category">
              {course.category}
            </span>

            <h2>{course.title}</h2>

            <p className="course-description">
              {course.description}
            </p>

            <div className="course-info">
              <span>⏱ {course.duration}</span>
              <span>📊 {course.level}</span>
            </div>

            <Link to={`/course/${course.id}`}>
              View Course →
            </Link>

          </div>

        ))}

      </div>

    </div>
  );
}

export default Courses;