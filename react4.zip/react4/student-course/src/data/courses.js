export const courses = [
  { id: 1, title: 'Modern Web Development', category: 'Development', description: 'Build responsive, accessible interfaces with today\'s essential web tools.', lessons: 18, level: 'Beginner', color: 'coral' },
  { id: 2, title: 'Product Design Fundamentals', category: 'Design', description: 'Learn how research, systems, and prototyping shape better products.', lessons: 14, level: 'Intermediate', color: 'blue' },
  { id: 3, title: 'Data & Decision Making', category: 'Business', description: 'Turn everyday data into clear insights and confident decisions.', lessons: 12, level: 'Beginner', color: 'gold' },
]