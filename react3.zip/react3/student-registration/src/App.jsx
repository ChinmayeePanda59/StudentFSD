import { useState } from "react";
import styles from "./App.module.css";

function App() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [course, setCourse] = useState("");

  const [student, setStudent] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();

    setStudent({
      name: name,
      email: email,
      course: course
    });
  };

  return (
    <div className={styles.container}>

      <div className={styles.formCard}>

        <h1>Student Registration</h1>
        <p className={styles.subtitle}>
          Register your details below
        </p>

        <form onSubmit={handleSubmit}>

          {/* Name */}
          <div className={styles.inputGroup}>
            <label>Name</label>

            <input
              type="text"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          {/* Email */}
          <div className={styles.inputGroup}>
            <label>Email</label>

            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          {/* Course */}
          <div className={styles.inputGroup}>
            <label>Course</label>

            <select
              value={course}
              onChange={(e) => setCourse(e.target.value)}
              required
            >
              <option value="">Select your course</option>
              <option value="B.Tech CSE">B.Tech CSE</option>
              <option value="B.Tech ECE">B.Tech ECE</option>
              <option value="BCA">BCA</option>
              <option value="B.Sc Computer Science">
                B.Sc Computer Science
              </option>
            </select>
          </div>

          <button type="submit">
            Register Student
          </button>

        </form>
      </div>


      {/* Submitted Details */}

      {student && (
        <div className={styles.resultCard}>

          <h2>Registration Successful 🎉</h2>

          <div className={styles.detail}>
            <span>Name</span>
            <strong>{student.name}</strong>
          </div>

          <div className={styles.detail}>
            <span>Email</span>
            <strong>{student.email}</strong>
          </div>

          <div className={styles.detail}>
            <span>Course</span>
            <strong>{student.course}</strong>
          </div>

        </div>
      )}

    </div>
  );
}

export default App;