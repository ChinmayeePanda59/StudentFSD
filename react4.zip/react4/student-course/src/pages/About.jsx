function About() {

  return (
    <div className="page about-page">

      <div className="about-content">

        <span className="page-tag">ABOUT EDUTRACK</span>

        <h1>Learn. Grow. Succeed.</h1>

        <p className="about-intro">
          EduTrack is a simple Student Course Management
          Application designed to help students explore
          and manage their learning journey.
        </p>

        <div className="about-grid">

          <div className="about-box">
            <div className="about-icon">🎓</div>
            <h3>Student Focused</h3>
            <p>
              Designed with students in mind to make
              course discovery simple and convenient.
            </p>
          </div>

          <div className="about-box">
            <div className="about-icon">📚</div>
            <h3>Quality Courses</h3>
            <p>
              Explore structured courses covering
              programming and web development.
            </p>
          </div>

          <div className="about-box">
            <div className="about-icon">🚀</div>
            <h3>Skill Development</h3>
            <p>
              Improve your technical skills through
              practical and career-oriented learning.
            </p>
          </div>

        </div>

       

      </div>

    </div>
  );
}

export default About;