import { useContext } from "react";
import { StudentContext } from "../context/StudentContext";

function Home() {

  const student = useContext(StudentContext);

  return (
    <div className="page home-page">

      <div className="hero">

        <h1>Welcome to EduTrack 🎓</h1>

        <p>
          Student Course Management Application
        </p>

        <div className="student-box">

          <h2>Student Information</h2>

          <p><strong>Name:</strong> {student.name}</p>
          <p><strong>Course:</strong> {student.course}</p>
          <p><strong>College:</strong> {student.college}</p>

        </div>

      </div>

    </div>
  );
}

export default Home;