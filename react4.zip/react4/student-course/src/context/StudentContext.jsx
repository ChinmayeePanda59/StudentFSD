import { createContext } from "react";

export const StudentContext = createContext();

export const StudentProvider = ({ children }) => {
  const student = {
    name: "Chinmayee Panda",
    course: "B.Tech CSE",
    college: "GIET University"
  };

  return (
    <StudentContext.Provider value={student}>
      {children}
    </StudentContext.Provider>
  );
};